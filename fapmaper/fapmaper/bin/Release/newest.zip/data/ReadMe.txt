//
// fapmap.exe -> "read me.txt"
//
=====[ Programs you should have ]=====
|	Put: ffmpeg.exe, youtube-dl.exe, webgrab.exe, fscan.exe, CrashHandler.exe ... 
|	in the same folder as fapmap.exe for everything to work

=====[ SCRIPTS ]=====
|	You can make your own script files.
|	Just add "fapmap_mod" in the name of the file (ex. [youtube-dl fapmap_mod.exe])
|	and when you open the file fapmap will prompt you with a window allowing
|	you to input command line arguments (%1, %2, %3, ...)
|	that will be passed onto the script/exe/program/...
|	I have already made some scripts... just extract the "scripts.rar" file
|	and a (scripts) folder should appear in the "Main Folder"
|	with all the scripts (Main Folder\scripts\*)...

=====[ ICONS FOR URL BOARD ]=====
|	After installing fapmap extract the favicons.rar (use: Right-Click -> Extract Here) ...
|	icons should appear in the ".\data\favicons" folder
|	
|	ADD YOUR OWN ICONS:
|		1. to add your own icons you'll have to view the HTML of the website (use CTRL+U)
|		2. than find (use CTRL+F) the 'favicon.ico' file 
|		3. locate the link of the .ico/.png/... (image) file
|		4. download the file
|		5. put it in the ".\data\favicons" folder with the name of the website
